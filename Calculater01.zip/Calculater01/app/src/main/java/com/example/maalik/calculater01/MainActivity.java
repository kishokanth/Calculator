package com.example.maalik.calculater01;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{


    public String input1,input2,answer1;

    Button  btnNine,btnEight,btnSeven,btnSix,btnfive,btnfour,btnThree,btnTwo,btnOne,btnZero,btnAdd,btnSub,btnMul,btnDev,btnEqual,btnDot,Clear;
    TextView answer;
    EditText Input;
    public Double value=null,value2=null;
    public String symbol;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOne=(Button)findViewById(R.id.btnOne);
        btnTwo=(Button)findViewById(R.id.btnTwo);
        btnThree=(Button)findViewById(R.id.btnThree);
        btnfour=(Button)findViewById(R.id.btnFour);
        btnfive=(Button)findViewById(R.id.btnFive);
        btnSix=(Button)findViewById(R.id.btnSix);
        btnSeven=(Button)findViewById(R.id.btnSeven);
        btnEight=(Button)findViewById(R.id.btnEight);
        btnNine=(Button)findViewById(R.id.btnNine);
        btnZero=(Button)findViewById(R.id.btnZero);
        btnDot=(Button)findViewById(R.id.btnDot);
        btnAdd=(Button)findViewById(R.id.btnAdd);
        btnSub=(Button)findViewById(R.id.btnSub);
        btnMul=(Button)findViewById(R.id.btnMul);
        btnDev=(Button)findViewById(R.id.btnDiv);
        btnEqual=(Button)findViewById(R.id.btnEqual);
        Clear=(Button) findViewById(R.id.Clear);
        Input=(EditText) findViewById(R.id.input);
        answer=(TextView)findViewById(R.id.Result);

        btnAdd.setBackgroundColor(0x00000000);
        btnSub.setBackgroundColor(0x00000000);
        btnMul.setBackgroundColor(0x00000000);
        btnDev.setBackgroundColor(0x00000000);


        btnOne.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Input.setText(Input.getText().insert(Input.getText().length(),"1"));
          }
        });

        btnTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"2"));
            }
        });


        btnThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"3"));
            }
        });


        btnfour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"4"));
            }
        });


        btnfive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"5"));
            }
        });


        btnSix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"6"));
            }
        });


        btnSeven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"7"));
            }
        });


        btnEight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"8"));
            }
        });


        btnNine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"9"));
            }
        });


        btnZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"0"));
            }
        });
        btnDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Input.setText(Input.getText().insert(Input.getText().length(),"."));
            }
        });

        btnMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valueS = Input.getText().toString();
                if (valueS.matches(""))
                {
                    Toast.makeText(getBaseContext(), "Please Enter The Number First", Toast.LENGTH_SHORT).show();
                }
                else {
                    btnMul.setBackgroundColor(Color.BLUE);

                    symbol = " * ";

                    value = Double.parseDouble(valueS);
                    Input.getText().clear();
                    answer.setText(valueS);
                    btnAdd.setEnabled(false);
                    btnSub.setEnabled(false);
                    btnDev.setEnabled(false);
                }



            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String valueS = Input.getText().toString();
                if (valueS.matches(""))
                {
                    Toast.makeText(getBaseContext(), "Please Enter The Number First", Toast.LENGTH_SHORT).show();
                }
                else {
                    btnSub.setBackgroundColor(Color.BLUE);

                    symbol = " - ";

                    value = Double.parseDouble(valueS);
                    Input.getText().clear();
                    answer.setText(valueS);
                    btnDev.setEnabled(false);
                    btnAdd.setEnabled(false);
                    btnMul.setEnabled(false);
                }
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valueS = Input.getText().toString();
                if (valueS.matches("")) {
                    Toast.makeText(getBaseContext(), "Please Enter The Number First", Toast.LENGTH_SHORT).show();
                } else {
                    btnAdd.setBackgroundColor(Color.BLUE);

                    symbol = " + ";

                    value = Double.parseDouble(valueS);
                    Input.getText().clear();
                    answer.setText(valueS);
                    btnDev.setEnabled(false);
                    btnSub.setEnabled(false);
                    btnMul.setEnabled(false);

                }
            }
        });

        btnDev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valueS = Input.getText().toString();
                if (valueS.matches(""))
                {
                    Toast.makeText(getBaseContext(), "Please Enter The Number First", Toast.LENGTH_SHORT).show();
                }
                else {
                btnDev.setBackgroundColor(Color.BLUE);

                symbol=" / ";

                value = Double.parseDouble(valueS);
                Input.getText().clear();
                answer.setText(valueS);
                btnAdd.setEnabled(false);
                btnSub.setEnabled(false);
                btnMul.setEnabled(false);
            }}
        });

        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(symbol==" / ")
               {
                   String answer1;
                   String valueS = Input.getText().toString();
                   value2 = Double.parseDouble(valueS);
                   answer1= Double.toString(value/value2);
                   answer.setText(answer1);

               }
                else if(symbol==" * ")
                {
                    String answer1;
                    String valueS = Input.getText().toString();
                    value2 = Double.parseDouble(valueS);
                    answer1= Double.toString(value*value2);
                    answer.setText(answer1);

                }
                else if(symbol==" - ")
                {
                    String answer1;
                    String valueS = Input.getText().toString();
                    value2 = Double.parseDouble(valueS);
                    answer1= Double.toString(value-value2);
                    answer.setText(answer1);

                }
                else if(symbol==" + ")
                {
                    String answer1;
                    String valueS = Input.getText().toString();
                    value2 = Double.parseDouble(valueS);
                    answer1= Double.toString(value+value2);
                    answer.setText(answer1);

                }


            }
        });

        Clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                btnDev.setEnabled(true);
                btnAdd.setEnabled(true);
                btnSub.setEnabled(true);
                btnMul.setEnabled(true);
                answer.setText("");
                Input.setText("");
                btnAdd.setBackgroundColor(0x00000000);
                btnSub.setBackgroundColor(0x00000000);
                btnMul.setBackgroundColor(0x00000000);
                btnDev.setBackgroundColor(0x00000000);
            }
        });



    }
}
